#!/usr/bin/env python
# coding:utf-8

import json


def main():
    filename = '/var/log/s3backup.log'
    backups = []

    try:
        with open(filename,'r') as f:
            lines = f.readlines()

        for line in lines:
            backups.append({"{#BAKJOB}":json.loads(line)['jobname']})

        print(json.dumps({"data":backups},indent = 4))

    except Exception:
        print(json.dumps({"data":backups},indent = 4))

if __name__ == "__main__":
    main()

