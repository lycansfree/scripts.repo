#!/bin/bash

if [ $# -eq 0 ];then
    echo "-1"
    exit 1
fi

_st=$1
_port=${2:-0}

if [ "${_port}" == 0 ];then
    if [ "${_st}" == "total" ];then
        netstat -ant | awk '{if($1 == "tcp") print $0}' | wc -l
    else
        netstat -ant | awk -v st=${_st} '{if($6 == st) print $0}' | wc -l
    fi
else
    if [ "${_st}" == "total" ];then
        netstat -ant | awk -v port=":${_port}$" '{if($4 ~ port) print $0}' | wc -l
    else
        netstat -ant | awk -v port=":${_port}$" -v st=${_st} '{if($4 ~ port && $6 == st) print $0}' | wc -l
    fi
fi
    

