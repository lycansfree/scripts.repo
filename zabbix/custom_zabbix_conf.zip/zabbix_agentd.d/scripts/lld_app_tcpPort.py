#!/usr/bin/env python
# coding:utf-8

# Author: lidong

import json
import os,sys
# import logging
# import traceback

def getTCPPort(procname):
    try:
        output = os.popen('''netstat -tlnp|grep '%s '|awk '{print $4}'|awk -F':' '{print $(NF)}'|sort -nu''' % (procname))
        outputs = output.readlines()
        ports = []
        for port in  outputs:
            port = port.strip('\n')
            try:
                ports += [{'{#PROCPORT}': int(port)}]
            except ValueError:
                pass
                # logging.debug(traceback.format_exc())
        print(json.dumps({'data':ports},sort_keys=True,indent=4))

    except Exception:
        pass
        # logging.debug(traceback.format_exc())

if __name__ == '__main__':
    # basedir = os.path.abspath(os.path.dirname(sys.argv[0]))
    # logging.basicConfig(level = logging.DEBUG,format = '%(asctime)s MSG:%(message)s',filename = os.path.join(basedir,sys.argv[0]) +'.log',filemode = 'a')
    getTCPPort(sys.argv[1])

