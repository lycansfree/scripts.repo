#!/usr/bin/env python
# coding:utf-8
   
import os,sys
import json
import re
   
def main():
    try:
        user = sys.argv[1]
    except Exception:
        user = 'bxapp'
  
    record = '/tmp/lld_procFind.json'
    try:
        with open(record, 'r') as f:
            lastR = json.load(f)
    except Exception:
        lastR = {}
   
    ExtraNames = [
        'bash', 'sh', 'sshd', 'python',
        'vim', 'su', 'sudo', 'vi',
        'less', 'more', 'ksh', 'sleep',
        'sendmail', 'postdrop'
    ]
    FindNames = []
    pids = os.popen("ps -u %s -o pid,etime | sed 1d" % user).readlines()
    recp = re.compile("^Name:\s*(.+)")
 
    for line in pids:
        line = line.strip(' \n').split()
        pid = line[0]
        etime = line[1].split('-')
        if len(etime) > 1:
            # 持续一天以上的进程被纳入
            tmpFile = "/proc/%s/status" % pid
            if os.path.isfile(tmpFile):
                with open(tmpFile, 'r') as f:
                    procNames = recp.findall(f.read())
                FindNames += procNames
   
    allNames = {}
    for x in FindNames:
        if x in ExtraNames:
            continue
  
        if allNames.get(x) is None:
            allNames[x] = 1
        else:
            allNames[x] += 1
   
    output = {"data": []}
    # 本次未检测到的,自减1
    for x in lastR:
        if x not in allNames:
            lastR[x] -= 2
            # 给曾经出现但当前未检测的设置默认1
            allNames[x] = 1
  
    # 本次检测到的,自加1
    for x in allNames:
        if lastR.get(x) is None:
            lastR[x] = 1
        else:
            lastR[x] += 1
 
        if lastR[x] > 48:
            lastR[x] = 48
        if lastR[x] < 0:
            lastR[x] = 0
  
        if lastR[x] > 24:
            output['data'].append({
                '{#PROCNAME}': x,
                '{#PROCNUM}': allNames[x]
            })
  
    with open(record, 'w') as f:
        json.dump(lastR, f, indent = 4)
               
    print(json.dumps(output, indent = 4, ensure_ascii = False))
   
if __name__ == '__main__':
    main()

