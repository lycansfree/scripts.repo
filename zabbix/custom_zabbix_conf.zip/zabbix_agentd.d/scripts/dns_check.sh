#!/bin/bash

domain=$1
target=$2

_host=`which host 2>/dev/null || exit 1`

t=`${_host} ${domain} | awk '{print $NF}'`
if [ ${t} == ${target} ];then
    echo 0
else
    echo 1
fi

