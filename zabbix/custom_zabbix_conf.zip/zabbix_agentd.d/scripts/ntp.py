#!/usr/bin/env python
# coding:utf-8

import commands
import re
import sys

# change log
# abs(offset) & less than 0 means error

def main():
    recp = re.compile('^\*(.+)',re.M)
    s,NTPQ = commands.getstatusoutput('which ntpq 2>/dev/null')
    if s > 0:
        print(-2)
        sys.exit(2)

    result = recp.findall(commands.getoutput(NTPQ + ' -p'))
    if len(result) == 0:
        print(-1)
    else:
        _offset = abs(float(result[0].split()[8]))
        print(_offset)
    
if __name__ == '__main__':
    main()

