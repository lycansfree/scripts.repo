#!/usr/bin/env python
# coding:utf-8

import json
import sys

def main():
    try:
        _jobname = sys.argv[1]
        _status = sys.argv[2]
    except Exception:
        print(3)
        sys.exit(1)
    
    # pre define
    filename = '/var/log/s3backup.log'
    
    with open(filename,'r') as f:
        lines = f.readlines()

    for line in lines:
        info = json.loads(line)
        if info['jobname'] == _jobname:
            if info['status'] == _status:
                print(1)
            else:
                print(0)
            sys.exit(0)

if __name__ == '__main__':
    main()

