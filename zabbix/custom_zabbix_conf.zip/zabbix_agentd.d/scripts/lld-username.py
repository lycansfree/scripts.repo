#!/usr/bin/env python
# coding:utf-8

import json

def main():
    with open('/etc/passwd','r') as f:
        lines = f.readlines()

    data = {"data":[]}
    for line in lines:
        line = line.strip('\r\n').split(':')
        if line[-1] == '/bin/bash':
            data['data'].append({"{#USERNAME}":line[0]})

    print(json.dumps(data,indent = 4))

if __name__ == '__main__':
    main()

