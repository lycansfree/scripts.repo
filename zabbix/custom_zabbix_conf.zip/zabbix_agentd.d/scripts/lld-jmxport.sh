#!/bin/bash

data="{\"data\":["
for _port in `ps -ef | grep -oP "(?<=jmxremote\.port=)\d+"`
do
    _comma=1
    data="${data}{\"{#JMXPORT}\":\"${_port}\"},"
done

if [ ${_comma:-0} -gt 0 ];then
    data=${data%?}
fi

data="${data}]}"

echo "${data}" | python -m json.tool

