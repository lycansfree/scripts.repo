#!/usr/bin/env python
# coding:utf-8

import json


def main():
    filename = '/proc/diskstats'
    devices = []
    skipdevs = ('sr','loop','ram')

    with open(filename,'r') as f:
        res = f.readlines()

    for line in res:
        _currdev = line.split()[2]
        if not any([_sdev in _currdev for _sdev in skipdevs]):
            devices.append({"{#DEVICENAME}":_currdev})

    print(json.dumps({"data":devices},indent = 4))
        
        

if __name__ == "__main__":
    main()

