#!/bin/bash

# check script exist
script="/etc/rc.d/init.d/EntegorAgent"
if [ ! -f "${script}" ];then
    echo "2"
    exit 2
fi

# check port status
_port=$1

netstat -lnt | awk '{print $4}' | grep -E ":${_port:-15000}$" 1>/dev/null 2>&1
if [ $? -gt 0 ];then
	sh ${script} restart 1>/dev/null 2>&1
	echo "1"
else
	echo "0"
fi
	
