#!/usr/bin/env python
# coding:utf-8

import re
# import commands
import os
import json
import sys
# import getpass

def main():
    # o = commands.getoutput('netstat -lntp 2>/dev/null | grep nginx')
    o = os.popen('netstat -lntp 2>/dev/null | grep nginx', 'r').read()
    recp = re.compile(".+?\s+.+?\s+.+?\s+.*?:(\d+)\s+.+",re.M)
    res = list(set(recp.findall(o)))
    data = {"data":[]}
    for port in res:
        data['data'].append({"{#NGXPORT}":port})

    print(json.dumps(data,indent = 4))
        
        
# if __name__ == '__main__' and getpass.getuser() == 'root':
if __name__ == '__main__':
    main()

