#!/usr/bin/env python
# coding:utf-8
  
import re
import os
import json
import sys
import datetime
  
def main():
    try:
        _edge = int(sys.argv[1])
    except Exception:
        _edge = 65536
    skipPort = ['8280','10001','15000']
    o = os.popen('netstat -lntp 2>/dev/null | grep java', 'r').read()
    # o = os.popen('netstat -lntp 2>/dev/null', 'r').read()
    recp = re.compile(".+?\s+.+?\s+.+?\s+.*?:(\d+)\s+.+?\s+.+?\s+(\d+)/.+", re.M)
    res = list(set(recp.findall(o)))
 
    data = {"data":[]}
    now = int(datetime.datetime.strftime(datetime.datetime.now(), '%s'))
    for port, pid in res:
        if port not in skipPort and int(port) < _edge:
            try:
                cmd = '''
                date -d "`ps -p %s -o lstart | sed 1d`" +'%%s'
                ''' % pid
                stime = int(os.popen(cmd, 'r').read())
                if (now - stime) > 86400:
                    data['data'].append({"{#JAVAPORT}": port})
     
            except Exception:
                pass
  
    print(json.dumps(data,indent = 4))
          
          
if __name__ == '__main__':
    main()

