#!/usr/bin/env python
# coding:utf-8

import zookeeper as zk
import sys,os
import json
import socket
import commands
import time
import re


class ZbxSender(object):
    def __init__(self,server = '127.0.0.1',host = '127.0.0.1',port = 10051,config = None):
        if config is not None:
            self.server = self.host = None
            recp = re.compile("^(?<!#)\s*(\w+)\s*=\s*(.+)",re.M)
            with open(config,'r') as f:
                content = f.read()
            reConf = recp.findall(content)
            for zbx_conf_name,zbx_conf_value in reConf:
                if zbx_conf_name == 'Server':
                    self.server = zbx_conf_value.split(',')[0]
                elif zbx_conf_name == 'Hostname':
                    self.host = zbx_conf_value.split(',')[0]
            
            if self.server is None:
                raise ValueError('zabbix_server配置异常')

            if self.host is None:
                self.host = socket.gethostname()

        else:
            self.server = server
            self.host = host

        self.port = port

        # request must be => 'sender data'
        self._packet = {
                'request':'sender data',
                'data':[]
                }

        # get localhost LANG
        _lang = os.getenv('LANG')
        if _lang is None:
            raise ValueError('语言编码$LANG获取失败')
        else:
            self._character = _lang.split('.')[-1].upper()
        

    def packMsg(self,key,value):
        tmp = {
                'host':self.host,
                'key':str(key),
                'value':str(value),
                'clock':int(time.time())
                }

        self._packet['data'].append(tmp)


    def cleanMsg(self):
        self._packet = {
                'request':'sender data',
                'data':[]
                }


    def formatMsg(self):
        _LANG = 'UTF-8'
        _character = self._character
        if _character == _LANG:
            return json.dumps(self._packet,ensure_ascii = False)
        else:
            return json.dumps(self._packet,ensure_ascii = False).decode(_character).encode(_LANG)

        
    def sendMsg(self):
        if len(self._packet['data']) == 0:
            raise IOError('发送数据前请先打包packMsg(host,key,value)')
        else:
            _packet = self.formatMsg()

        try:
            sk = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            sk.settimeout(3)
        except Exception,e:
            raise IOError(str(e))

        try:
            sk.connect((self.server,self.port))
            sk.send(_packet)
            # time.sleep(1)
            # print sk.recv(1024)
        except Exception,e:
            raise ValueError(str(e))
        finally:
            sk.close()


def checkPort(_server,_port):
    try:
        sk = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        sk.settimeout(0.2)
        sk.connect((_server,_port))
        sk.close()
        return True
    except Exception,e:
        return False
    

def getZKHandler(target):
    _port = 2181
    _server = None

    try:
        if target == 'test':
            for i in ['172.20.0.24']:
                if checkPort(i,_port):
                    _server = i
                    break
        elif target == 'prod':
            for i in ['10.1.9.14','10.1.1.32','10.1.3.20','10.1.7.13','10.1.2.22']:
                if checkPort(i,_port):
                    _server = i
                    break
        else:
            raise ValueError('环境只能为[test|prod]')

        if _server is None:
            raise IOError('没有存活的zk可以连接')

        handler = zk.init('%s:%d' % (_server,_port))
    except Exception,e:
        print str(e)
        sys.exit(2)

    return handler
    

def main():
    try:
        _target = sys.argv[1]
    except Exception:
        _target = 'unknown'
    handler = getZKHandler(_target)
    _entrance = '/SERVER_TOPOLOGY'
    onlines = offlines = 0
    # 小疑惑,为什么链式赋值 _services = _ips = {}会导致后面结果异常
    # 猜测,赋值是内存空间的引用,但是简单实验不能复现这个结果
    # 复现,直接的等号赋值,会改变变量存储的地址,但是如果是对字典元素进行赋值,则字典变量本身的地址不变,即
    # _services 和 _ips的地址仍然一样,_ips中元素变量会存储新的地址,导致_services指向的内存存储数据变化
    _services = {}
    _ips = {}
    

    # service-id ip:port数量 onlines数量 offlines数量 实例数量
    # ip:port service-id数量 onlines数量 offlines数量

    try:
        for i in zk.get_children(handler,_entrance):
            _currdir = os.path.join(_entrance,i)
            if zk.get(handler,_currdir)[1]['numChildren'] > 0:
                # ip:port
                if i not in _ips:
                    _ips[i] = {'service-ids':[],'onlines':0,'offlines':0}
                
                for j in zk.get_children(handler,_currdir):
                    _endpoints = os.path.join(_currdir,j)
                    _sv = j[:6]
                    # ip:port
                    if _sv not in _ips[i]['service-ids']:
                        _ips[i]['service-ids'].append(_sv)

                    # service-id
                    if _sv not in _services:
                        _services[_sv] = {'ips':[],'onlines':0,'offlines':0,'total':1}
                        _services[_sv]['ips'].append(i)
                    else:
                        _services[_sv]['total'] += 1
                        if i not in _services[_sv]['ips']:
                            _services[_sv]['ips'].append(i)
                    
                    if zk.get(handler,_endpoints)[0] == 'online':
                        onlines += 1
                        _ips[i]['onlines'] += 1
                        _services[_sv]['onlines'] += 1
                    else:
                        offlines += 1
                        _ips[i]['offlines'] += 1
                        _services[_sv]['offlines'] += 1

        zk.close(handler)

        message = ''
        message += "#" * 75 + '\n'
        message += "%-30s%-15s%-15s%-15s" % ('主机维度','provider数量','服务onlines','服务offlines') + '\n'
        for _ip_ in _ips:
            message += "%-30s%-15d%-15d%-15d" % (_ip_,len(_ips[_ip_]['service-ids']),_ips[_ip_]['onlines'],_ips[_ip_]['offlines']) + '\n'
        message += "#" * 75 + '\n'
        message += "%-15s%-15s%-15s%-15s%-15s" % ('服务维度','实例数量','服务onlines','服务offlines','主机[端口]数量') + '\n'
        for _sv_ in _services:
            message += "%-15s%-15d%-15d%-15d%s" % (_sv_,_services[_sv_]['total'],_services[_sv_]['onlines'],_services[_sv]['offlines'],','.join(_services[_sv_]['ips'])) + '\n'
        message += "#" * 75 + '\n'
            
            

    except Exception,e:
        print str(e)
        sys.exit(2)

    print message

    # zabbix sender
    _zbx = ZbxSender(config = '/etc/zabbix/zabbix_agentd.conf')
    _zbx.packMsg('custom.zk.status.total',onlines + offlines)
    _zbx.packMsg('custom.zk.status.onlines',onlines)
    _zbx.packMsg('custom.zk.status.offlines',offlines)
    _zbx.sendMsg()


if __name__ == '__main__':
    main()

