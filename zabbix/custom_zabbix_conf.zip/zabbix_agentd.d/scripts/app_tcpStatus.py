#!/usr/bin/env python
# coding:utf-8

# Author: lidong

import json
import os,sys
import subprocess
# import logging
# import traceback

def getTCPStatus(data):
    tcpcmd = "ss"
    try:
        output = subprocess.check_call(["which",tcpcmd],stdout = subprocess.PIPE)
    except subprocess.CalledProcessError:
        tcpcmd = "netstat"
        try:
            output = subprocess.check_call(["which",tcpcmd],stdout = subprocess.PIPE)
        except subprocess.CalledProcessError:
            return
    except:
        # logging.debug(traceback.format_exc())
        return
        
    try:
        if len(data) == 3:
            output = os.popen('''%s -tan | grep ':%s' | grep -i '%s' | wc -l''' % (tcpcmd,int(data[1]),data[2]))
            print( output.read().strip())
        elif len(data) == 2:
            try:
                output = os.popen('''%s -tan | grep ':%s' | wc -l''' % ( tcpcmd,int(data[1]) ))
                print( output.read().strip())
            except ValueError:
                output = os.popen('''%s -tan | grep -i '%s' | wc -l''' % (tcpcmd,data[1]))
                print( output.read().strip())
        else:
            output = os.popen('''%s -ta | wc -l''')
            print( output.read().strip())
            
    except Exception:
        pass
        # traceback.print_exc()
        # logging.debug(traceback.format_exc())


if __name__ == '__main__':
    # basedir = os.path.abspath(os.path.dirname(sys.argv[0]))
    # logging.basicConfig(level = logging.INFO,format = '%(asctime)s MSG:%(message)s',filename = os.path.join(basedir,sys.argv[0]) +'.log',filemode = 'a')
    getTCPStatus(sys.argv)

