#!/bin/bash

user=$1
_type=$2

if [ "${_type}" == "maxFiles" ];then
    su - ${user} -c "ulimit -n"
elif [ "${_type}" == "maxProc" ];then
    su - ${user} -c "ulimit -u"
elif [ "${_type}" == "lsof" ];then
    lsof -u ${user} | wc -l
fi
