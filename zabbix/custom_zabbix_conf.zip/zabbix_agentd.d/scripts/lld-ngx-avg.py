#!/usr/bin/env python
# coding:utf-8

import json
import os,sys
import socket

def main():
    hostname = socket.gethostname()
    syscode = hostname[3:6]
    workdir = os.path.join('/var/log',syscode,'nginx_logs')

    zbx = {"data":[]}
    if os.path.isdir(workdir):
        os.chdir(workdir)

        for i in os.listdir(workdir):
            if os.path.isfile(i):
                _pre,_suffix = os.path.splitext(i)
                if _suffix == '.log':
                    zbx['data'].append({"{#NGXAVG}":_pre})

    print(json.dumps(zbx,indent = 4))


if __name__ == '__main__':
    main()

