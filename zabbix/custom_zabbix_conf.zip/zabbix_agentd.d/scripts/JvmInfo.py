#!/usr/bin/env python
# coding:utf-8

# return one response to server by print
# and send data by trapper
# java -jar cmdline-jmxclient.jar USER:PASS HOST:PORT [BEAN] [COMMAND]

import os,sys
import re
import socket
import time
import json


class ZbxSender(object):
    def __init__(self,server = '127.0.0.1',host = '127.0.0.1',port = 10051,config = None):
        if config is not None:
            self.server = self.host = None
            recp = re.compile("^(?<!#)\s*(\w+)\s*=\s*(.+)",re.M)
            with open(config,'r') as f:
                content = f.read()
            reConf = recp.findall(content)
            for zbx_conf_name,zbx_conf_value in reConf:
                if zbx_conf_name == 'Server':
                    self.server = zbx_conf_value.split(',')[0]
                elif zbx_conf_name == 'Hostname':
                    self.host = zbx_conf_value.split(',')[0]
            
            if self.server is None:
                raise ValueError('zabbix_server config exception')

            if self.host is None:
                self.host = socket.gethostname()

        else:
            self.server = server
            self.host = host

        self.port = port

        # request must be => 'sender data'
        self._packet = {
                'request':'sender data',
                'data':[]
                }

        # get localhost LANG
        _lang = os.getenv('LANG')
        if _lang is None:
            raise ValueError('Get System $LANG Failed')
        else:
            self._character = _lang.split('.')[-1].upper()
        

    def packMsg(self,key,value):
        tmp = {
                'host':self.host,
                'key':str(key),
                'value':str(value),
                'clock':int(time.time())
                }

        self._packet['data'].append(tmp)


    def cleanMsg(self):
        self._packet = {
                'request':'sender data',
                'data':[]
                }


    def formatMsg(self):
        _LANG = 'UTF-8'
        _character = self._character
        if _character == _LANG:
            return json.dumps(self._packet,ensure_ascii = False)
        else:
            return json.dumps(self._packet,ensure_ascii = False).decode(_character).encode(_LANG)

        
    def sendMsg(self):
        if len(self._packet['data']) == 0:
            raise IOError('Please packMsg(host,key,value) before send data')
        else:
            _packet = self.formatMsg()

        try:
            sk = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            sk.settimeout(3)
        except Exception as e:
            raise IOError(str(e))

        try:
            sk.connect((self.server,self.port))
            sk.send(_packet)
            # time.sleep(1)
            # print sk.recv(1024)
        except Exception as e:
            raise ValueError(str(e))
        finally:
            sk.close()


def MemUsage(_zbx,exec_jar,_command,_port):
    _key = 'custom.jvm.%s' % _command
    _bean = 'java.lang:type=Memory'
    (s,o) = commands.getstatusoutput('%s %s %s' % (exec_jar,_bean,_command))
    if s > 0:
        raise IOError(_command + ' exception')

    recp = re.compile("(committed|init|max|used):\s*(\d+)",re.M)
    res = recp.findall(o)
    for name,value in res:
        _zbx.packMsg('%s.%s[%s]' % (_key,name,_port),int(value))

    return _zbx


def CpuUsage(_zbx,exec_jar,_command,_port):
    _key = 'custom.jvm.%s[%s]' % (_command,_port)
    _bean = 'java.lang:type=OperatingSystem'
    (s,o) = commands.getstatusoutput('%s %s %s' % (exec_jar,_bean,_command))
    if s > 0:
        raise IOError(_command + ' exception')

    _zbx.packMsg(_key,float(o.split()[-1]))
    return _zbx


def ThreadUsage(_zbx,exec_jar,_command,_port):
    _key = 'custom.jvm.%s[%s]' % (_command,_port)
    _bean = 'java.lang:type=Threading'
    (s,o) = commands.getstatusoutput('%s %s %s' % (exec_jar,_bean,_command))
    if s > 0:
        raise IOError(_command + ' exception')

    _zbx.packMsg(_key,int(o.split()[-1]))
    return _zbx


def RuntimeUsage(_zbx,exec_jar,_command,_port):
    _key = 'custom.jvm.%s[%s]' % (_command,_port)
    _bean = 'java.lang:type=Runtime'
    (s,o) = commands.getstatusoutput('%s %s %s' % (exec_jar,_bean,_command))
    if s > 0:
        raise IOError(_command + ' exception')

    _zbx.packMsg(_key,int(o.split()[-1]))
    return _zbx
    

def main():
    try:
        _zbx = ZbxSender(config = '/etc/zabbix/zabbix_agentd.conf')
        basedir = os.path.abspath(os.path.dirname(sys.argv[0]))
        _jar = os.path.join(basedir,'cmdline-jmxclient.jar')
        _host = '127.0.0.1'
        _port = sys.argv[1]
        exec_jar = 'java -jar %s - %s:%s' % (_jar,_host,_port)
        
        # HeapMemoryUsage
        _zbx = MemUsage(_zbx,exec_jar,'HeapMemoryUsage',_port)

        # NonHeapMemoryUsage
        _zbx = MemUsage(_zbx,exec_jar,'NonHeapMemoryUsage',_port)

        # ProcessCpuTime
        _zbx = CpuUsage(_zbx,exec_jar,'ProcessCpuTime',_port)

        # ProcessCpuLoad
        _zbx = CpuUsage(_zbx,exec_jar,'ProcessCpuLoad',_port)

        # Uptime
        _zbx = RuntimeUsage(_zbx,exec_jar,'Uptime',_port)

        # ThreadCount
        _zbx = ThreadUsage(_zbx,exec_jar,'ThreadCount',_port)

        # PeakThreadCount
        _zbx = ThreadUsage(_zbx,exec_jar,'PeakThreadCount',_port)

        _zbx.sendMsg()

        print(1)

    except Exception:
        print(0)

if __name__ == '__main__':
    if sys.version[:1] == '3':
        print(3)
        sys.exit(3)

    import commands
    main()

